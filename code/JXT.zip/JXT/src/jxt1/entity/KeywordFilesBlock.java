package jxt1.entity;

import sks.entity.KeywordFiles;

public class KeywordFilesBlock {
    public KeywordFiles[] kfs;
}
