package jxt1.entity;

import java.util.Vector;

public class JXTXSetBlock {
    public byte[] wj;
    public byte[] keyword_enc;
    public Vector<String> xtag= new Vector<String>();

}


