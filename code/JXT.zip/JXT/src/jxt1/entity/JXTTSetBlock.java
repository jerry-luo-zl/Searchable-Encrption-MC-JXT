package jxt1.entity;

import jxt1.entity.JXTTSetTuple;

public class JXTTSetBlock {


    public byte[] keyword_enc;
    public JXTTSetTuple[] t;
}
