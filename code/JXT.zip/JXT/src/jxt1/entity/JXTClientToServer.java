package jxt1.entity;

public class JXTClientToServer {
    public byte[] stag;
    public JXTClientToServer(int n){

    }
}
