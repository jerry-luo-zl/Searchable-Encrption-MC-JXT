package jxt1.entity;


public class JXTTSetTuple {
    public byte[] ct;
    public ytuple[] y ;
}
