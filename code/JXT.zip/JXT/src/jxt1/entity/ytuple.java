package jxt1.entity;
import it.unisa.dia.gas.jpbc.Element;
public class ytuple {
    public Element y1,y2;
    public byte[] t;
}
