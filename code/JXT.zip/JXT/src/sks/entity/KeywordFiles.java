package sks.entity;

import java.io.Serializable;

public class KeywordFiles implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public String keyword;
	public int[] files;
}
