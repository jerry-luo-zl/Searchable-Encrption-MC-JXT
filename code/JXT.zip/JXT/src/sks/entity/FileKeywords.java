package sks.entity;

import java.io.Serializable;

public class FileKeywords implements Serializable{
    private static final long serialVersionUID = 1L;

    public int index;
    public String[] keywords;
}
