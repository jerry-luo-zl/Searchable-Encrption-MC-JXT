package util;

import client.entity.KV;
import client.entity.KV;

import java.io.*;
import java.nio.ByteBuffer;

public class tool {
    public static long bytesToLong(byte[] bytes) {
        long num = 0;
        for (int ix = 0; ix < 8; ++ix) {
            num <<= 8;
            num |= (bytes[ix] & 0xff);
        }
        return num;
    }
    public static byte[] longtoBytes(long num){
        byte[] byteNum = new byte[8];
        for(int ix = 0; ix < 8; ++ix) {
            int offset = 64 - ( ix + 1 ) *8;
            byteNum[ix] = (byte) ((num>> offset ) & 0xff);
        }
        return byteNum;
    }




    public static void WriteDataToFile(KV[] kv_list,String s) throws IOException {
        BufferedWriter bw = null;
        try {
            File file = new File(s);
            bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
            String current = kv_list[0].key;
            for (int i = 0; i < kv_list.length; ) {
                bw.write("key:  "+kv_list[i].key+"   value:  ");
                while (i< kv_list.length&&current.equals(kv_list[i].key)) {
                    bw.write(kv_list[i].value+","+kv_list[i].counter+"  " );
                    i++;
                }
                if(i< kv_list.length)
                    current = kv_list[i].key;
                bw.newLine();
                bw.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != bw) {
                bw.close();
            }
        }
    }


    public static int[] TtS(int inNum, int index, int level) {
        int[] result = new int[level];
        int i = 0;
        while(i<level) {
            result[i]=(inNum % index);
            inNum = inNum / index;
            i++;
        }
        return result;
    }

}
