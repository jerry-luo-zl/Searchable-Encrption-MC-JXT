package client.entity;


import java.io.Serializable;

public class EY implements Serializable {
    public byte[] e;
    public byte[] y;
}
