package client.entity;

import java.io.Serializable;
import java.util.ArrayList;

public class EYList implements Serializable {
    public ArrayList<EY> EY_List;
}
