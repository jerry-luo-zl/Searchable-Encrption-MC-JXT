package main.java.client.entity;

import java.io.Serializable;

public class VK implements Serializable {
    public String value;
    public String key;
}
