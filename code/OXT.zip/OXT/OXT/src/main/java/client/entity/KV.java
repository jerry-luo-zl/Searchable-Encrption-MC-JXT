package client.entity;

import java.io.Serializable;

public class KV implements Serializable {
    public String key;
    public String value;
    public int counter;
}
