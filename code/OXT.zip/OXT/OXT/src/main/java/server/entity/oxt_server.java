package server.entity;

import client.entity.EY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class oxt_server implements Serializable {
    public HashMap<String, EY[]> TSet;
    public HashSet<String> XSet;

}
